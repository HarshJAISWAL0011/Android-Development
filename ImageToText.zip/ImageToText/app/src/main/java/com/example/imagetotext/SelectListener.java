package com.example.imagetotext;


public interface SelectListener {

    void onItemClicked(String mymodel,String action);
}
