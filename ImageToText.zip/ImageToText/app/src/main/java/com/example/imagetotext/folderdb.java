package com.example.imagetotext;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class folderdb extends SQLiteOpenHelper {

    public folderdb( Context context) {
        super(context, "folder.db", null, 1);
    }

    @Override
    public void onCreate ( SQLiteDatabase DB ) {
        DB.execSQL("create Table folder(Username text,Foldername text);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists folder");
    }

    public Boolean insertuserdata(String uname,String fname)
    {

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Username", uname);
        contentValues.put("Foldername", fname);


        long result=DB.insert("folder", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }


    Cursor getdataLimited (String[] name) {
        SQLiteDatabase db = this.getReadableDatabase ();
        String[] projection = {
                "Foldername",
                "Username",
        };

        String whereClause = "Username = ?";
        Cursor cursor = db.query (
                "folder",
                projection,
                whereClause,
                name,
                null,
                null,
                null );
        int result = cursor.getCount ();
        Log.d ( "Database folder", "Table is completed" + result );
        return cursor;
    }

}
