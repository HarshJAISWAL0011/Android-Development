package com.example.imagetotext;

public class ModelClass {

    private byte[] imageview;
    private String name;
    private String time;
    private String scan;




    ModelClass (byte[] imageview ,String name,String time,String uri)
    {
        this.imageview=imageview;
        this.name=name;
        this.time=time;
        this.scan=uri;
    }

    public byte[] getImageview() {
        return imageview;
    }

    public String getName() {
        return name;
    }



    public String getTime() {
        return time;
    }

    public String getUri() {
        return scan;
    }


}
