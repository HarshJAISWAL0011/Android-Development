package com.example.imagetotext;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Fadapter extends RecyclerView.Adapter<Fadapter.ViewHolder> {


    private ArrayList<FolderClass> folderlist;
    private SelectListener listener;
    RelativeLayout rl;
    View view;

    public Fadapter ( ArrayList<FolderClass> folderlist, SelectListener listener ) {
        this.folderlist = folderlist;
        this.listener = listener;
     
    }


    @NonNull
    @Override
    public Fadapter.ViewHolder onCreateViewHolder ( @NonNull ViewGroup parent, int viewType ) {
        view = LayoutInflater.from ( parent.getContext () ).inflate ( R.layout.folderview, parent, false );
        return new ViewHolder ( view );
    }

    @Override
    public void onBindViewHolder ( Fadapter.ViewHolder holder, final int position ) {

        String foldername = folderlist.get ( position ).getFoldername ();
        holder.setData ( foldername );


    }

    @Override
    public int getItemCount ( ) {
      return folderlist.size ();
    }




    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView nameView;
        private RelativeLayout frl;


        public ViewHolder ( @NonNull View itemView ) {
            super ( itemView );
           //hooks
            nameView = itemView.findViewById ( R.id.foldername_id );
            frl=itemView.findViewById ( R.id.f_relative );

        }

        public void setData ( String f_name ) {

            nameView.setText ( f_name );
            frl.setOnClickListener ( new View.OnClickListener () {
                @Override
                public void onClick ( View view ) {
                    listener.onItemClicked ( f_name ,"j ");

                }
            } );

        }
    }

}



