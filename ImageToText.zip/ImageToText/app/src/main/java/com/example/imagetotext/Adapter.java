package com.example.imagetotext;



import android.annotation.SuppressLint;
import android.app.Activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;

import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private ArrayList<ModelClass> userList;
    private ArrayList<ModelClass> selectlist;
    private SelectListener listener;
    RelativeLayout rl;
    MainViewModel mainViewmodel;
    View view;

    boolean isSelectall=false;
    boolean isEnabled=false;
    Activity activity;

    public Adapter ( ArrayList<ModelClass> userList , SelectListener listener, Activity activity ) {
        this.userList = userList;
        this.listener=listener;
        this.activity=activity;
        selectlist=new ArrayList<> ();
    }


    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder ( @NonNull ViewGroup parent, int viewType ) {

        view = LayoutInflater.from ( parent.getContext () ).inflate ( R.layout.item_design, parent, false );
        //for live data update
        mainViewmodel= ViewModelProviders.of (( FragmentActivity) activity).get ( MainViewModel.class );
        return new ViewHolder ( view );
    }



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder ( @NonNull Adapter.ViewHolder holder, @SuppressLint ("RecyclerView") final int position ) {
        holder.setIsRecyclable(false);      //to stop recycler view to recycle its position value
        byte[] resource = userList.get ( position ).getImageview ();
        String name = userList.get ( position ).getName () ;        //File name
        String uri=userList.get ( position ).getUri();
        String time=userList.get ( position ).getTime ();
        holder.setData ( resource, name,time );
        Log.d ( "Adapter","in onBindViewHolder" );

        holder.rl1.setOnLongClickListener ( new View.OnLongClickListener () {
            @Override
            public boolean onLongClick ( View view ) {
                selectlist.clear ();
                if(!isEnabled){
                    //To perform move and copy functionality
                    ActionMode.Callback callback=new ActionMode.Callback () {
                        @Override
                        public boolean onCreateActionMode ( ActionMode actionMode, Menu menu ) {
                            MenuInflater menuInflater= actionMode.getMenuInflater ();
                            menuInflater.inflate ( R.menu.select,menu );
                            return true;
                        }

                        @Override
                        public boolean onPrepareActionMode ( ActionMode actionMode, Menu menu ) {
                            isEnabled=true;
                            ClickItem(holder);
                            //live updating data-->No. of selected items
                            mainViewmodel.getData ().observe ( (LifecycleOwner) activity, new Observer<String> () {
                                @Override
                                public void onChanged ( String s ) {
                                    actionMode.setTitle ( String.format("%s Selected",s) );
                                }
                            } );
                            return true;
                        }

                        @Override
                        public boolean onActionItemClicked ( ActionMode actionMode, MenuItem menuItem ) {
                            int id=menuItem.getItemId ();
                            String name="";
                            int i=0;
                            switch (id) {
                                case R.id.nav_copy:
                                    name="";
                                    i=0;
                                    //getting all selected names
                                    while(selectlist.size ()>i) {
                                        name=name+"-"+selectlist.get ( i ).getName ();
                                        i++;}
                                    name=name+"-";
                                    listener.onItemClicked ( name,"copy" );
                                    actionMode.finish ();
                                    break;
                                case R.id.nav_move:

                                    actionMode.finish ();
                                    name="";
                                    i=0;
                                    while(selectlist.size ()>i) {
                                        name=name+"-"+selectlist.get ( i ).getName ();
                                        i++;}
                                    name=name+"-";

                                    listener.onItemClicked ( name,"move" );
//
                                    break;
                                case R.id.nav_selectall:
                                    if (selectlist.size () == userList.size ())
                                    {           isSelectall = false;
                                        selectlist.clear ();
                                    }

                                    else{
                                        isSelectall=true;
                                        selectlist.clear ();
                                        selectlist.addAll ( userList );

                                    }
                                    mainViewmodel.setData ( String.valueOf ( selectlist.size () ) );
                                    notifyDataSetChanged ();
                                    break;


                                default:
                                    Toast.makeText ( activity, "Something went Wrong", Toast.LENGTH_SHORT ).show ();

                            }
                            return false;
                        }

                        @Override
                        public void onDestroyActionMode ( ActionMode actionMode ) {
                            isEnabled=false;
                            isSelectall=false;
                            notifyDataSetChanged ();
                        }
                    };
                    ((AppCompatActivity)view.getContext ()).startActionMode ( callback );
                }
                else{
                    ClickItem ( holder );
                }


                return true;
            }
        } );

        holder.itemView.findViewById ( R.id.rll ).setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick ( View view ) {
                if(isEnabled)
                    ClickItem ( holder );
                else{
                    listener.onItemClicked ( uri,"pass" ); }

            }
        } );

        if(isSelectall){

            holder.checkboxView.setVisibility ( View.VISIBLE );
            holder.rl1.setBackgroundColor ( Color.LTGRAY );
        }
        else
        {
            holder.checkboxView.setVisibility ( View.GONE );
            holder.itemView.setBackgroundColor ( activity.getColor(R.color.change) );
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void ClickItem (ViewHolder holder ) {
        ModelClass s =userList.get(holder.getAdapterPosition ());
        if(holder.checkboxView.getVisibility ()==View.GONE ){

            holder.checkboxView.setVisibility ( View.VISIBLE );
            holder.rl1.setBackgroundColor ( Color.LTGRAY );
            selectlist.add(s);
        }
        else {
            holder.checkboxView.setVisibility ( View.GONE );
            holder.rl1.setBackgroundColor (  activity.getColor(R.color.change) );
            selectlist.remove ( s );
        }
        mainViewmodel.setData ( String.valueOf ( selectlist.size () ) );
    }

    @Override
    public int getItemCount ( ) {
        return userList.size ();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageView;
        private ImageView checkboxView;
        private TextView nameView;
        private TextView timeView;
        RelativeLayout rl1;


        public ViewHolder ( @NonNull View itemView ) {
            super ( itemView );
            //here use xml ids
            //give different name not like constructor
            imageView = itemView.findViewById ( R.id.imageview );
            checkboxView = itemView.findViewById ( R.id.checkbox );
            rl1=itemView.findViewById ( R.id.rll );
            nameView = itemView.findViewById ( R.id.name0 );
            timeView = itemView.findViewById ( R.id.time0 );
            Log.d ( "Adapter","in ViewHolder" );

            rl=itemView.findViewById ( R.id.rll );

        }

        public void setData ( byte[] resource, String name,  String time) {

            Bitmap image= BitmapFactory.decodeByteArray( resource, 0, resource.length);
            imageView.setImageBitmap (image );
            nameView.setText ( name );
            timeView.setText ( time );
        }


    }


}