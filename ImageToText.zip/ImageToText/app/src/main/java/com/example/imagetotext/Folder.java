package com.example.imagetotext;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Folder extends AppCompatActivity implements SelectListener {

    RecyclerView frecyclerView;
    LinearLayoutManager flayoutManager;
    ArrayList<FolderClass> folderlist;
    Fadapter fadapter;
    String username;
    folderdb db;
    String[] whereArgs;
    AlertDialog adialog;
    String pdfname,action,folder;


    @Override
    public boolean onCreateOptionsMenu (Menu menu ) {
        MenuInflater inflater=getMenuInflater ();
        inflater.inflate ( R.menu.folder_icon,menu );
        return true;
    }


    @Override
    protected void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_folder );
        getSupportActionBar ().setTitle ( "Files" );
        getSupportActionBar ().setDisplayHomeAsUpEnabled(true);


        username = getIntent ().getExtras ().getString ( "username" );
        action = getIntent ().getExtras ().getString ( "action" );
        pdfname = getIntent ().getExtras ().getString ( "pdfname" );
        folder = getIntent ().getExtras ().getString ( "folder" );

        if(action!=null) {
            if (pdfname != null) {

                pdfname=pdfname.substring ( 1,pdfname.length () );
                if(pdfname.charAt(pdfname.length()-2)=='-'){
                    pdfname=pdfname.substring (0,pdfname.length ()-1 );

                }

            }
        }
        db = new folderdb ( this );
        if (username != null) {

            folderlist = new ArrayList<> ();
            initData ();
            initRecyclerView ();
        }








    }

    private void initRecyclerView() {
        frecyclerView=findViewById( R.id.folder_RecyclerView);
        flayoutManager = new LinearLayoutManager ( this);
        flayoutManager.setOrientation( RecyclerView.VERTICAL);
        frecyclerView.setLayoutManager(flayoutManager);
        Log.d ( "initRecycler","================"+folderlist );
        fadapter=new Fadapter(folderlist,this);
        frecyclerView.setAdapter(fadapter);
        //  folderlist.clear ();
        fadapter.notifyDataSetChanged();

    }


    private void initData() {
        whereArgs = new String[]{      //dont make it global
                username
        };
        folderlist = new ArrayList<> ();

        Cursor c = db.getdataLimited ( whereArgs );
        int i = 0;
        if ((c != null) && (c.getCount () > 0)) {
            c.moveToLast ();
            do {
                i = i + 1;
                folderlist.add ( new FolderClass ( c.getString ( 0 ) ) );
            } while (c.moveToPrevious ());
        }



    }



    void popupwindow() {

        AlertDialog.Builder dialog = new AlertDialog.Builder ( this );
        View popup = getLayoutInflater ().inflate ( R.layout.newfolder, null );


        Button save = (Button) popup.findViewById ( R.id.save );
        Button cancel = popup.findViewById ( R.id.cancel );
        dialog.setView ( popup );
        adialog = dialog.create ();




        save.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick ( View view ) {
                EditText nameview = (EditText) popup.findViewById ( R.id.folder_name );

                String name = nameview.getText ().toString ().trim();
                if(name.isEmpty())
                    Toast.makeText(Folder.this, "Folder not Created", Toast.LENGTH_SHORT).show();
                else{
                boolean result = db.insertuserdata ( username, name );
                if (result) {
                    adialog.dismiss ();
                    FolderClass newdata=new FolderClass ( name );
                    folderlist.add (  0,newdata);
                    fadapter.notifyDataSetChanged ();
                    //this is used to refresh whole activity
//                    Intent intent = new Intent ( Folder.this, Folder.class );
//                    finish();
//                    overridePendingTransition(0, 0);
//                    startActivity(getIntent());
//                    overridePendingTransition(0, 0);
                }}
            }
        } );

        cancel.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick ( View view ) {
                adialog.dismiss ();
            }
        } );
        adialog.show ();

    }


    @Override
    public void onItemClicked ( String folder_name,String actio ) {
        String uri = getIntent ().getExtras ().getString ( "username" );
        if (action==null) {
            Intent intent = new Intent ( Folder.this, History.class );
            intent.putExtra ( "username", username );
            intent.putExtra ( "foldername", folder_name );
            intent.putExtra ( "uri",uri );
            startActivity ( intent );
        }

        else if(action.equals ( "copy" )) {


            String uri1 = "";
            Database db2 = new Database ( this );

            int index = -1;
            String str = "";


            if (pdfname != null) {


                while (pdfname.indexOf ( "-" ) != -1) {

                    pdfname = pdfname.substring ( index + 1, pdfname.length () );

                    index = pdfname.indexOf ( "-" );
                    if (index == -1)
                        str = pdfname.substring ( 0, pdfname.length () );
                    else
                        str = pdfname.substring ( 0, pdfname.indexOf ( "-" ) );


                    SQLiteDatabase DB = db2.getWritableDatabase ();
                    Cursor cursor1 = DB.rawQuery ( "Select * from stored where name=? and Foldername=? and pdfname=?", new String[]{username, folder, str} );
                    Cursor cursor2 = DB.rawQuery ( "Select * from stored where name=? and Foldername=? ", new String[]{username, folder_name} );

                    int matched=0;
                    if(!str.isEmpty())
                    while(cursor2.moveToNext())
                    {
                        Log.d("folder","pdfname and database  "+str+" & "+cursor2.getString(4));
                        if(str.equals(cursor2.getString(4))) {
                            matched = 1;
                        Log.d("folder"," copy database matched");
                        }
                    }



                   if(matched==0){
                    if (cursor1.getCount () > 0) {

                        while (cursor1.moveToNext ()) {

                            Log.d("Folder", "cursor value is" + cursor1.getString(1) + cursor1.getString(2) + folder_name + cursor1.getString(3) + cursor1.getString(4) + cursor1.getBlob(5));


                            String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                            boolean result = db2.insertuserdata(cursor1.getString(2), username, folder_name, currentTime, str, cursor1.getBlob(5));
                            if (result)
                                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
                        }

                        }
                    }
                   else
                       Toast.makeText(this, "Duplicate data exist", Toast.LENGTH_SHORT).show();
                }


                Intent intent = new Intent ( Folder.this, History.class );
                intent.putExtra ( "username", username );
                intent.putExtra ( "foldername", folder_name );
                startActivity ( intent );


            }
        }



        else {

            int index = -1;
            String str = "";
            Database db1 = new Database ( this );
            long result=1;
            if (pdfname != null) {
                while (pdfname.indexOf ( "-" ) != -1) {

                    pdfname = pdfname.substring(index + 1, pdfname.length());

                    index = pdfname.indexOf("-");
                    if (index == -1)
                        str = pdfname.substring(0, pdfname.length());
                    else
                        str = pdfname.substring(0, pdfname.indexOf("-"));

                    SQLiteDatabase DB = db1.getWritableDatabase();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("Foldername", folder_name);

                    Cursor cursor2 = DB.rawQuery("Select * from stored where name=? and Foldername=? ", new String[]{username, folder_name});

                    int matched = 0;
                    if(!str.isEmpty())
                    while (cursor2.moveToNext()) {
                        Log.d("folder", "pdfname and database " + str + " &" + cursor2.getString(4));
                        if (str.equals(cursor2.getString(4)))
                        {   Log.d("folder","move database matched");
                          matched = 1;}

                    }


                    if (matched == 0) {

                        Cursor cursor3 = DB.rawQuery("Select * from stored where pdfname = ? and name=? and Foldername=?" , new String[]{str, username,folder});
                        int id=0;
                        while(cursor3.moveToNext())
                            id=cursor3.getInt(6);

                        Cursor cursor = DB.rawQuery("Select * from stored where pdfname = ? and name=? and Foldername=? and id=?" 
                                , new String[]{str, username,folder,Integer.toString(id)});
                        Cursor cursor4 = DB.rawQuery("Select * from stored where pdfname = ? and name=? and Foldername=? "
                                , new String[]{str, username,folder_name});


                        if (cursor.getCount() > 0) {
                            if(cursor4.getCount()<=0)

                            result = DB.update("stored", contentValues, "pdfname=? and Foldername=? and name=?", new String[]{str,folder,username});
                            if (result == -1)
                                Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
                            else {
                                Toast.makeText(this, "Moved" , Toast.LENGTH_SHORT).show();
                            }
                        }


                    }
                    else
                        Toast.makeText(this, "Item already present", Toast.LENGTH_SHORT).show();
                }

if(result!=-1) {
    Intent intent = new Intent(Folder.this, History.class);
    intent.putExtra("username", username);
    intent.putExtra("foldername", folder_name);
    startActivity(intent);
}
            }
        }

    }


    @Override
    public void onBackPressed() {

        Intent intent= new Intent (this,MainActivity.class);
        intent.putExtra("username",username);
        startActivity(intent);

       //super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item ) {

        if (item.getItemId () == R.id.nav_folder) {
            popupwindow ();

        }
        if (item.getItemId () == android.R.id.home) {
//                Intent intent = new Intent ( this, MainActivity.class);
//                startActivity ( intent );
//                finish (); // close this activity and return to preview activity (if there is any)
            super.onBackPressed ();
        }


        return super.onOptionsItemSelected ( item );
    }


}