package com.example.imagetotext;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class Entrydb  extends SQLiteOpenHelper {

    public Entrydb( Context context) {
        super(context, "entry.db", null, 1);
    }

    @Override
    public void onCreate ( SQLiteDatabase DB ) {
        DB.execSQL("create Table entry(Email text,Username text,password text);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists entry");
    }

    public Boolean insertuserdata(String email,String uname,String pass)
    {

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Username", uname);
        contentValues.put("Email", email);
        contentValues.put("password", pass);

        long result=DB.insert("entry", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor getdata () {
        SQLiteDatabase DB = this.getWritableDatabase ( );
        Cursor cursor = DB.rawQuery ( "Select * from entry" , null );
        return cursor;

    }

}


