package com.example.imagetotext;

public class FolderClass {

    private String foldername="";


    public FolderClass ( String foldername ) {
        this.foldername = foldername;
    }

    public String getFoldername ( ) {
        return foldername;
    }


}
