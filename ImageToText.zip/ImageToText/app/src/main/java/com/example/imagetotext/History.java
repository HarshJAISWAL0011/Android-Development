package com.example.imagetotext;

import static com.example.imagetotext.R.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EmptyStackException;
import java.util.List;
import java.util.Locale;

public class History extends AppCompatActivity implements SelectListener{

    RecyclerView mrecyclerView;
    LinearLayoutManager layoutManager;
    ArrayList<ModelClass> userList;
    Adapter adapter;
    String username,folder="Default";
    ModelClass modelClass1;
    Database database1;
    ImageView imageViewq;
    String[] whereArgs;
    String pdfnamedel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( layout.history);

        imageViewq=findViewById ( id.emptyImage );
        username=getIntent().getExtras().getString("username");
        folder=getIntent().getExtras().getString("foldername");
        String action=getIntent().getExtras().getString("action");


        imageViewq.setVisibility ( View.GONE );

        getSupportActionBar ().setTitle ( folder );

        initData();
        initRecyclerView();
        Database db=new Database ( this );
        boolean re=db.deletedata ( "hh" );//to delete data left from snack


        db.close ();
        if(userList.isEmpty ()) {
            imageViewq.setVisibility ( View.VISIBLE );
            findViewById ( id.relative ).setBackgroundColor ( getResources ().getColor ( color.black ) );
        }
        //Swipe to delete method
        ItemTouchHelper itemTouchHelper=new ItemTouchHelper ( simpleCallback );
        itemTouchHelper.attachToRecyclerView ( mrecyclerView );
    }

    //for back button on top
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void initRecyclerView() {
        mrecyclerView=findViewById( id.RecyclerView);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        mrecyclerView.setLayoutManager(layoutManager);
        adapter=new Adapter(userList,this,History.this);
        mrecyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }
    private void initData() {
        //get only those file which belongs to particular user and
        //is of particular folder selected by user
        if (!username.isEmpty ()&&!folder.isEmpty ()) {
            whereArgs = new String[]{
                    username,folder
            };

            userList = new ArrayList<> ();
            database1 = new Database ( this );
            Cursor c = database1.getdataLimited ( whereArgs );
            int i = 0;
            if ((c != null) && (c.getCount () > 0)) {
                c.moveToLast ();
                do {
                    i = i + 1;
                    userList.add ( new ModelClass ( c.getBlob ( 4 ), c.getString ( 5 ), c.getString ( 0 ), c.getString ( 2 ) ) );
                } while (c.moveToPrevious ());

            }
        }
    }


//swipe pdf to delete
    ItemTouchHelper.SimpleCallback simpleCallback=new ItemTouchHelper.SimpleCallback ( 0, ItemTouchHelper.LEFT) {
        @Override
        public boolean onMove ( @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target ) {
            return false;

        }

        @Override
        public void onSwiped ( @NonNull RecyclerView.ViewHolder viewHolder, int direction ) {
            int position=viewHolder.getAdapterPosition ();

            switch (direction){
                case ItemTouchHelper.LEFT:
                    modelClass1=userList.get ( position );
                    pdfnamedel=modelClass1.getName ();
                    userList.remove ( position );

                    boolean result=database1.updateuserdata ( pdfnamedel,"hh" );


                    adapter.notifyItemRemoved ( position );
                    Snackbar.make( mrecyclerView, pdfnamedel, Snackbar.LENGTH_LONG)
                            .setAction ( "undo", new View.OnClickListener () {
                                @Override
                                public void onClick ( View view ) {
                                    userList.add ( position, modelClass1 );
                                    boolean result2= database1.updateuserdata (pdfnamedel,username);
                                    if(result2)
                                        adapter.notifyItemInserted ( position );
                                }
                            } ).setBackgroundTint ( getResources ().getColor ( color.bg ) ).setTextColor ( getResources ().getColor ( color.white)).show ();
//
                    break;

                default:
                    Toast.makeText ( History.this, "No action should be performed", Toast.LENGTH_SHORT ).show ();
            }
        }
    };



    @Override
    public void onItemClicked (String s,String action ) {
        if(action.equalsIgnoreCase ("move"))
        {
            Intent intent = new Intent ( this, Folder.class );
            intent.putExtra ( "pdfname", s );
            intent.putExtra ( "folder",folder );
            intent.putExtra ( "username",username);
            intent.putExtra ( "action", "move" );

            startActivity ( intent );
        }
        else if(action.equals ( "copy" )){

            Intent intent = new Intent ( this, Folder.class );
            intent.putExtra ( "pdfname", s );
            intent.putExtra ( "username",username);
            intent.putExtra ( "folder",folder );
            intent.putExtra ( "action", "copy" );

            startActivity ( intent );

        }
        else {
            Intent intent = new Intent ( this, PdfView.class );
            intent.putExtra ( "path", s );
            startActivity ( intent );
        }
    }
}