package com.example.imagetotext;

import android.app.ActivityOptions;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class Login extends AppCompatActivity {
    ImageView image;
    //TextInputLayout name ,passw;
    TextInputEditText namel;
    TextInputEditText Pass;
    Button goButton;
    @Override
    protected void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.splash );
//            name=(TextInputLayout) findViewById ( R.id.boxinSplash );
//            passw=(TextInputLayout) findViewById ( R.id.password_toggleinSplash);
        goButton=findViewById ( R.id.gotoSingup);
        image=findViewById ( R.id.car1 );
        namel=findViewById ( R.id.fullname_splash );
        Pass=findViewById ( R.id.password_splash );
        findViewById ( R.id.signup ).setOnClickListener ( new View.OnClickListener () {


            @Override
            public void onClick ( View view ) {
                Intent intent=new Intent ( Login.this, Signup.class);
                Pair[] pair=new Pair [4];
                pair[0]=new Pair<View,String>(namel,"fullname");
                pair[1]=new Pair<View,String>(Pass,"pass");
                pair[2]=new Pair<View,String>(goButton,"but");
                pair[3]=new Pair<View,String>(image,"logo_image");
                ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation ( Login.this, pair );
                startActivity ( intent,options.toBundle ());

                startActivity ( intent );
            }
        } );
        goButton.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick ( View view ) {
                String usernamel=namel.getText ().toString ().trim ();
                String pass=Pass.getText ().toString ();

                if (!usernamel.isEmpty() && Patterns.EMAIL_ADDRESS.matcher( usernamel).matches()) {


                    Entrydb db = new Entrydb ( Login.this );
                    Cursor c = db.getdata ();
                    String usernamepass="";
                    int i = 1;
                    int k = -1;
                    while (c.moveToNext ()) {
//                        Log.d ( "Login ", "username database" + usernamel + c.getString ( 0 ) + c.getString ( 1 )+ c.getString ( 2 )+ i + " " + k );
                        if (c.getString ( 0).equalsIgnoreCase ( usernamel )) {
                            usernamepass=c.getString ( 1);
                            k = i;
                            break;
                        }
                        Log.d ( "Login ", "username database" + usernamel + c.getString ( 1 ) + i + " " + k );
                        i++;
                    }
                    //  Toast.makeText ( Login.this, "username "+usernamel+c.getString ( 1 ), Toast.LENGTH_SHORT ).show ();

                    if (k == -1)
                        namel.setError ( "New User? Sign Up" );
                        // Toast.makeText ( Login.this, "No such UserName", Toast.LENGTH_SHORT ).show ();
                    else {
                        if (c.getString ( 2 ).equals ( pass )) {
                Intent intent = new Intent ( Login.this, MainActivity.class );
                intent.putExtra ( "username", usernamepass );
                startActivity ( intent );
                         Login.this.finish ();

                        } else {
                            Toast.makeText ( Login.this, "Incorrect Password", Toast.LENGTH_SHORT ).show ();
                            Pass.setError ( "Incorrect Password" );
                        }
                    }


                }
                else{
                    namel.setError( "Invalid Email" );
                 //   namel.setError ( null );
                }
            }
        } );
    }

    @Override
    public void onBackPressed ( ) {

        Login.this.finish ();
    System.exit ( 0 );

    }
}