package com.example.imagetotext;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.google.android.material.navigation.NavigationView;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.InterruptedByTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;


    public class MainActivity extends AppCompatActivity {
        Button capture,copy;
        private static final int PERMISSION_REQUEST_CODE = 420;
        TextView tv,heading0;
        int code=123;
        Bitmap bitmap;
        Canvas canvas;
        Random random;

        byte[] img;
        boolean isSaved=false;
        ImageView imageView;

        PdfDocument.Page myPage;
        PdfDocument.PageInfo mypageInfo;
        StringBuilder stringBuilder;
        Database database;
        String completeword="", pdfname, username,pdfpath;
        Button copied;


        @Override
        public boolean onCreateOptionsMenu ( Menu menu ) {
            MenuInflater inflater=getMenuInflater ();
            inflater.inflate ( R.menu.menu_item,menu );

            return true;
        }

        @Override
        protected void onCreate ( Bundle savedInstanceState ) {
            super.onCreate ( savedInstanceState );
            setContentView ( R.layout.activity_main );

            //hooks
            heading0=findViewById ( R.id.heading );
            copied=findViewById ( R.id.copy );
            capture=findViewById ( R.id.capture );
            copy =findViewById ( R.id.copy );
            tv=findViewById ( R.id.data );
            imageView=findViewById ( R.id.image );

            if (checkPermission()) {
                Toast.makeText(com.example.imagetotext.MainActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                requestPermission();
            }

            //for upload function
            StrictMode.VmPolicy.Builder builder=new StrictMode.VmPolicy.Builder ();
            StrictMode.setVmPolicy ( builder.build () );
            builder.detectFileUriExposure ();

            random=new Random();

            Toolbar toolbar = findViewById( R.id.toolbar);
            setSupportActionBar(toolbar);
            toolbar.setTitleTextColor ( Color.BLACK );

            username=getIntent().getExtras().getString("username");

            heading0.setText ( "Hey, "+username );
            database=new Database ( this );

//            if(ContextCompat.checkSelfPermission ( com.example.imagetotext.MainActivity.this, Manifest.permission.CAMERA )!= PackageManager.PERMISSION_GRANTED){
//                ActivityCompat.requestPermissions ( com.example.imagetotext.MainActivity.this,new String[]{Manifest.permission.CAMERA},code );
//            }

            capture.setOnClickListener ( new View.OnClickListener () {
                @Override
                public void onClick ( View view ) {
                    //pass command to get image and crop
                    CropImage.activity().setGuidelines ( CropImageView.Guidelines.ON).start( com.example.imagetotext.MainActivity.this);
                    copied.setText ( "Copy" );
                    findViewById ( R.id.title ).setVisibility ( View.GONE );
                }
            } );



            copy.setOnClickListener ( new View.OnClickListener () {
                @Override
                public void onClick ( View view ) {
                    String scanned_text=tv.getText ().toString ();
                    copytoclipboard (  scanned_text);
                }
            } );


        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode,@Nullable Intent data1) {
            findViewById ( R.id.card ).setVisibility ( View.VISIBLE );
            super.onActivityResult ( requestCode, resultCode, data1 );
            isSaved=false;

            if(requestCode== CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
                CropImage.ActivityResult result=CropImage.getActivityResult (data1);
                if(resultCode==RESULT_OK){


//                    String s=result.getUri ().toString ();

                    InputStream imageStream = null;
                    try {
                        imageStream = getContentResolver().openInputStream( result.getUri());
                    } catch (FileNotFoundException e) {
                        e.printStackTrace ();
                    }
                    //get image from user and store in Database in byte code
                    final Bitmap selectedImage = BitmapFactory.decodeStream( imageStream);
                    ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream ();
                    //Reduce size of image
                    Bitmap bMapScaled = Bitmap.createScaledBitmap(selectedImage, 150, 100, true);
                    bMapScaled.compress ( Bitmap.CompressFormat.PNG,10,byteArrayOutputStream);

                    img=byteArrayOutputStream.toByteArray();
                    imageView.setImageBitmap(selectedImage);


                    Uri resultUri=result.getUri();
                    try {
                        bitmap= MediaStore.Images.Media.getBitmap (  this.getContentResolver (),resultUri);
                        getTextFromImage ( bitmap );
                    } catch (IOException e) {
                        e.printStackTrace ();
                    }

                }
                else
                    Toast.makeText ( this, "Error while Cropping Image", Toast.LENGTH_SHORT ).show ();
            }
        }

        @Override
        public boolean onOptionsItemSelected ( @NonNull MenuItem item ) {
            switch (item.getItemId ()) {
                case R.id.nav_share:

                    if(saveInsert ()){
                        String path= pdfpath+"/"+pdfname;
                        File file=new File ( path );
                        Intent share = new Intent ();
                        share.setAction ( Intent.ACTION_SEND );
                        share.putExtra ( Intent.EXTRA_STREAM,Uri.fromFile ( file ) );
                        share.setType ( "application/pdf" );
                        startActivity ( share );}
                    break;
                case R.id.nav_files:
                    Intent intent=new Intent (com.example.imagetotext.MainActivity.this,Folder.class);
                    intent.putExtra ( "username",username );
                    startActivity ( intent );
                    break;
                case R.id.nav_save:
                    saveInsert();
                    break;
                case R.id.nav_logout:
                    Intent intent0=new Intent (com.example.imagetotext.MainActivity.this,Login.class);
                    startActivity ( intent0 );
                    this.finish();
                    break;
                default:
                    Toast.makeText ( this, "Some error occurred", Toast.LENGTH_SHORT ).show ();

            }
            return true;

        }


        boolean saveInsert()
        {
            if( completeword!="") {
                //contains some word and start pdf generating process
                if (isSaved == false) {
                                isSaved=true;
                    try {
                        createPdf();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                        Toast.makeText(com.example.imagetotext.MainActivity.this, "Error while creating PDF", Toast.LENGTH_SHORT).show();
                    }

                    String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                    boolean result = database.insertuserdata(pdfpath + "/" + pdfname, username, "Default", currentTime, pdfname, img);

                    return true;
                }
                else{
                    Toast.makeText ( this, "Already Saved", Toast.LENGTH_SHORT ).show ();
                return false;}
            }
            else
                Toast.makeText ( this, "Empty Pdf Cannot be Saved", Toast.LENGTH_SHORT ).show ();
            return false;
        }



        private void getTextFromImage( Bitmap bitmap){

            TextRecognizer recognizer=new TextRecognizer.Builder( this).build();

            Frame frame=new Frame.Builder().setBitmap( bitmap).build();
            SparseArray <TextBlock> textBlockSparseArray=recognizer.detect ( frame );

            if(textBlockSparseArray.size()<=0){
                Toast.makeText ( com.example.imagetotext.MainActivity.this, "No Text Detected", Toast.LENGTH_SHORT ).show ();
                tv.setText ("");
                completeword="";
            }
            else{
                stringBuilder= new StringBuilder ();

//
                for(int i=0;i<textBlockSparseArray.size ();i++){
                    TextBlock textBlock= textBlockSparseArray.valueAt ( i );
                    stringBuilder.append ( textBlock.getValue () );
                    stringBuilder.append ( "\n" );
                }
                completeword=stringBuilder.toString ();


                tv.setText ( stringBuilder.toString () );

            }
            capture.setText ( "Retake" );
            copy.setVisibility ( View.VISIBLE );
        }



        private  void copytoclipboard(String text){
            ClipboardManager clipboardManager= (ClipboardManager) getSystemService ( Context.CLIPBOARD_SERVICE );
            ClipData clip= ClipData.newPlainText ( "Copied data",text );
            clipboardManager.setPrimaryClip ( clip );
            Toast.makeText ( com.example.imagetotext.MainActivity.this, "Copied", Toast.LENGTH_SHORT ).show ();
            copied.setText ( "Copied" );
        }


        void createPdf() throws FileNotFoundException {
            PdfDocument  pdfDocument = new PdfDocument();
            Paint  title = new Paint();
            mypageInfo = new PdfDocument.PageInfo.Builder( 950, 1820, 1).create();
            // start page for our PDF file.
            myPage = pdfDocument.startPage(mypageInfo);

            canvas = myPage.getCanvas();
            title.setTextSize ( 18 );

            String s="";
            Scanner scan=new Scanner ( stringBuilder.toString () );
            do{
                s=s+scan.nextLine()+"\n";

            } while(scan.hasNextLine ());

            TextPaint mTextPaint = new TextPaint();
            mTextPaint.setTextSize ( 25 );
            title.setTextAlign( Paint.Align.CENTER);
            //defining spacing and wrapping of text
            StaticLayout mTextLayout = new StaticLayout ( s , mTextPaint, canvas.getWidth() - 30, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
            canvas.save();
            int textX = 30;
            int textY = 90;
            canvas.translate(textX, textY);
            mTextLayout.draw ( canvas );
            pdfDocument.finishPage(myPage);

            File myDirectory = new File(Environment.getExternalStorageDirectory(), "Documents");
            //creating directory if does not exist
            if(!myDirectory.exists()) {
                myDirectory.mkdirs();
            }

            pdfpath= Environment.getExternalStoragePublicDirectory ( Environment.DIRECTORY_DOCUMENTS).toString ();
            database=new Database ( this );
            Cursor c= database.getdata ();
            //random int to generate pdf number
            int r=random.nextInt((80-65)+65);

            int id=0;
            while(c.moveToNext ())
                id++;
            pdfname="ImageToText"+Integer.toString ( id*r*3434 )+".pdf";


            File file = new File( pdfpath, pdfname);
            try {
                pdfDocument.writeTo(new FileOutputStream ( file));

                Toast.makeText( com.example.imagetotext.MainActivity.this, "PDF file generated successfully.", Toast.LENGTH_SHORT).show();


                //Notification
                NotificationManager mNotificationManager =
                        (NotificationManager) getSystemService( Context.NOTIFICATION_SERVICE);
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel( "YOUR_CHANNEL_ID",
                            "YOUR_CHANNEL_NAME",
                            NotificationManager.IMPORTANCE_DEFAULT);
                    channel.setDescription("YOUR_NOTIFICATION_CHANNEL_DESCRIPTION");
                    mNotificationManager.createNotificationChannel(channel);
                }
                CharSequence title1="Pdf Created Successfully. ";
                CharSequence message="Pdf is stored at emulated/Documents/ImageToText/"+pdfname;
                NotificationCompat.Builder mBuilder = new NotificationCompat.Builder( getApplicationContext(), "YOUR_CHANNEL_ID")
                        .setSmallIcon(R.drawable.logo) // notification icon
                        .setContentTitle(title1) // title for notification
                        .setContentText(message)// message for notification
                        .setLargeIcon (bitmap)
                        .setAutoCancel(true); // clear notification after click
                Intent intents = new Intent(this, com.example.imagetotext.MainActivity.class);
                PendingIntent pi = PendingIntent.getActivity( getApplicationContext (), 0, intents, PendingIntent.FLAG_UPDATE_CURRENT);
                mBuilder.setContentIntent(pi);
                mNotificationManager.notify(0, mBuilder.build());
            } catch (IOException e) {

                e.printStackTrace();
            }
            pdfDocument.close();
        }


        private boolean checkPermission() {
            int permission1 = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            int permission2 = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
            return permission1 == PackageManager.PERMISSION_GRANTED && permission2 == PackageManager.PERMISSION_GRANTED;
        }

        private void requestPermission() {
            // requesting permissions if not provided.
            ActivityCompat.requestPermissions( this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }

        @Override
        public void onRequestPermissionsResult( int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            super.onRequestPermissionsResult ( requestCode, permissions, grantResults );
            if (requestCode == PERMISSION_REQUEST_CODE) {
                if (grantResults.length > 0) {

                    // after requesting permissions we are showing
                    // users a toast message of permission granted.
                    boolean writeStorage = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean readStorage = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (writeStorage && readStorage) {
                        Toast.makeText ( this, "Permission Granted..", Toast.LENGTH_SHORT ).show ();
                    } else {
                        Toast.makeText ( this, "Permission Denined.", Toast.LENGTH_SHORT ).show ();
                        finish ();
                    }
                }
            }


        }

        @Override
        public void onBackPressed ( ) {
            //Alert dialog to exit
            AlertDialog dialog = new AlertDialog.Builder ( this )
                    .setTitle ( " Logout ?" )
                    .setMessage ( "Are you sure you want to Logout ?" )
                    .setIcon ( R.drawable.ic_baseline_exit_to_app_24 )

                    .setNegativeButton ( "Cancel", null )
                    .setPositiveButton ( "Logout", new DialogInterface.OnClickListener () {
                        @Override
                        public void onClick ( DialogInterface dialog, int which ) {
                            Intent intent =new Intent (com.example.imagetotext.MainActivity.this,Login.class);
                            startActivity ( intent );
                            com.example.imagetotext.MainActivity.this.finish();
                        }
                    } )
                    .show ();


        }

        public void onclicked ( String s ) {
            copytoclipboard (  s);
        }
    }