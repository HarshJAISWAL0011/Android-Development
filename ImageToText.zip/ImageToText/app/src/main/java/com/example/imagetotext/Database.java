package com.example.imagetotext;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class Database extends SQLiteOpenHelper {

    public Database( Context context) {
        super(context, "User.db", null, 1);
    }

    @Override
    public void onCreate ( SQLiteDatabase DB ) {
        DB.execSQL("create Table stored(time text,name text,Uri text,Foldername text,pdfname text,image blob,id integer primary key autoincrement);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists stored");
    }

    public Boolean insertuserdata(String uri,String name,String fldr,String time,String pdfname, byte[] image)
    {

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Uri", uri);
        contentValues.put("name", name);
        contentValues.put("time", time);
        contentValues.put("image", image);
        contentValues.put("pdfname", pdfname);
        contentValues.put("Foldername", fldr);

        long result=DB.insert("stored", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }



    public Boolean updateuserdata(String pdfname,String username) {

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", username);

        Cursor cursor = DB.rawQuery( "Select * from stored where pdfname = ?", new String[]{pdfname});
        if (cursor.getCount() > 0) {
            long result = DB.update("stored", contentValues, "pdfname=?", new String[]{pdfname});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }}


    public Boolean deletedata (String name)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from stored where name = ?", new String[]{name});
        if (cursor.getCount() > 0) {
            long result = DB.delete("stored", "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }

    }

    public Cursor getdata ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from stored", null);
        return cursor;

    }


    Cursor getdataLimited (String[] name) {
        SQLiteDatabase db = this.getReadableDatabase ();
        String[] projection = {
                "time",
                "name",
                "Uri",
                "Foldername",
                "image",
                "pdfname"
        };

        String whereClause = "name = ?  AND Foldername= ?";

        Cursor cursor = db.query (
                "stored",
                projection,
                whereClause,
                name,
                null,
                null,
                null );
        return cursor;
    }


}
