package com.example.imagetotext;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class Signup extends AppCompatActivity {

    TextInputEditText Uname;
    TextInputEditText Fname;
    TextInputEditText Pass;
    TextInputEditText Cpass;

    @Override
    public void onBackPressed() {

        Intent intent=new Intent(this,Login.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_singup );

        Uname=findViewById ( R.id.username );
        Fname=findViewById ( R.id.ffname);
        Pass=findViewById ( R.id. passwor);
        Cpass=findViewById ( R.id.cnfmpass );


        findViewById ( R.id.gotoProfile ).setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick ( View view ) {
                String uname=Uname.getText ().toString().trim ();
                String emails=Fname.getText ().toString().trim ();
                String passs=Pass.getText ().toString();
                String cpass=Cpass.getText ().toString();

                int l=0;
                int i = 1;
                int k = -1;
                Entrydb db = new Entrydb ( Signup.this );
                Cursor c = db.getdata ();
                while (c.moveToNext ()) {

                    if (c.getString ( 0 ).equalsIgnoreCase ( emails )) {l=5;break;}

                    if (c.getString ( 1 ).equalsIgnoreCase ( uname )) {
                        k = i;
                        break;
                    }
                    i++;
                }
                c.close ();

                //Validating Credentials
                if (!emails.isEmpty() && Patterns.EMAIL_ADDRESS.matcher( emails).matches()) {
                    if(l==0){
                    if (passs.length () < 7) {
                        Pass.setError ( "Password too weak" );
                        Toast.makeText ( Signup.this, "Password should not be less than 8 character", Toast.LENGTH_SHORT ).show ();
                    } else {
                        if(uname.isEmpty ())
                            Uname.setError ( "Feild Cannot be Empty" );
                        else{
                        if(uname.length ()<3)
                            Uname.setError ( "Invalid Username" );
                        else{
                        if (cpass.equals ( passs )) {
                            if (k == -1) {
                                boolean result = db.insertuserdata ( emails, uname, passs );
                                if (result)
                                    Toast.makeText ( Signup.this, "Registered", Toast.LENGTH_SHORT ).show ();
                                else
                                    Toast.makeText ( Signup.this, "Data Not Inserted", Toast.LENGTH_SHORT ).show ();

                                folderdb d=new folderdb(Signup.this);
                                SQLiteDatabase DB = d.getWritableDatabase();
                                Intent intent = new Intent ( Signup.this, Login.class );
                                startActivity ( intent );

                            } else
                                Toast.makeText ( Signup.this, "Username Already taken.", Toast.LENGTH_SHORT ).show ();
                        } else {
                            Pass.setError ( "Password Did not Matched" );
                            Cpass.setError ( "Password Did not Matched" );
                        }
                    }}}
                    }
                    else
                    Toast.makeText ( Signup.this, "Email is already registered", Toast.LENGTH_SHORT ).show ();
                }
                else
                    Fname.setError ( "Invalid Email" );

            }
        } );
    }
}